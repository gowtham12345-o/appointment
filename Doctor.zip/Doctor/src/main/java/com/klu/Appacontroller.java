package com.klu;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin(origins ={"http://localhost:5173", "http://localhost:5174"}, allowCredentials = "true")
@RequestMapping("/doctor")
public class Appacontroller {

    @Autowired
    private DoctorService service;

    @PostMapping("/doctor")
    public String InsertData(@RequestBody Doctor doctor) {
        return service.insertDoctor(doctor);
    }

    @GetMapping("/doctors")
    public List<Doctor> getAllDoctors() {
        return service.getAllDoctors();
    }

    @PostMapping("/auth")
    public ResponseEntity<Object> logindoctor(@RequestBody Doctor doctor) {
        Doctor existing = service.getDoctorByEmail(doctor.getEmail());
        
        if (existing == null) {
            return ResponseEntity.status(404).body("User not found");
        }

        if (existing.getPassword().equals(doctor.getPassword())) {
            return ResponseEntity.ok(new LoginResponse("login successful", existing.getName(), existing.getEmail()));
        } else {
            return ResponseEntity.status(401).body("Incorrect password");
        }
    }
}
