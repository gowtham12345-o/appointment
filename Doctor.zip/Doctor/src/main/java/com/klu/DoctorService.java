package com.klu;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class DoctorService {
	@Autowired
	Doctorrepo doctorrepo;
	
	public String insertDoctor(Doctor doctor) {
		doctorrepo.save(doctor);
		return "inserted";
	}
	 public List<Doctor> getAllDoctors() {
	        return doctorrepo.findAll();
	    }

	 public Doctor getDoctorByEmail(String email) {
		 return doctorrepo.findByEmail(email).orElse(null);
	 }
	 public Optional<Doctor> findDoctorByEmail(String email) {
	        return doctorrepo.findByEmail(email);
	    }
}
